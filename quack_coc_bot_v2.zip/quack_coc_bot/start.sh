#!/bin/bash

# Restart ADB server
adb kill-server
adb start-server

# Run bot
cd src
python3 main.py
