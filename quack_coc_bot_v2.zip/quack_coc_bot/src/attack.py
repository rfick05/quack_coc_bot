import time
import random
from adb_utils import adb_tap, adb_swipe
from image_utils import wait_for_template
from coordinates import COORDS


def jitter_coord(x, y, jitter_range=10):
    return x + random.randint(-jitter_range, jitter_range), y + random.randint(-jitter_range, jitter_range)


def get_drop_coords(number=1):
    rage_mid = (1202, 104)
    rage_top = (1197, 238)
    rage_bot = (1190, 725)
    rage2_right_up = (935, 345)
    rage2_right_down = (935, 570)
    rage2_left_up = (1400, 345)
    rage2_left_down = (1400, 570)

    if number == 1:
        left_x = random.randint(78, 110)
        right_x = random.randint(480, 514)
        mid_x = random.randint(269, 310)
        left_y = round(-0.8165 * left_x + 542.68)
        right_y = round(-0.8165 * right_x + 542.68)
        mid_y = round(-0.8165 * mid_x + 542.68)
        return left_x, left_y, right_x, right_y, mid_x, mid_y, rage_mid, rage_top, rage_bot, rage2_right_up, rage2_right_down

    elif number == 2:
        left_x = random.randint(120, 150)
        right_x = random.randint(350, 400)
        mid_x = random.randint(220, 280)
        left_y = round(0.865 * left_x + 376.2)
        right_y = round(0.865 * right_x + 376.2)
        mid_y = round(0.865 * mid_x + 376.2)
        return left_x, left_y, right_x, right_y, mid_x, mid_y, rage_mid, rage_top, rage_bot, rage2_right_up, rage2_right_down

    elif number == 3:
        left_x = random.randint(1755, 1795)
        right_x = random.randint(2270, 2318)
        mid_x = random.randint(1990, 2060)
        left_y = round(0.74 * left_x - 1120)
        right_y = round(0.74 * right_x - 1120)
        mid_y = round(0.74 * mid_x - 1120)
        return left_x, left_y, right_x, right_y, mid_x + 5, mid_y, rage_mid, rage_top, rage_bot, rage2_left_up, rage2_left_down


def find_attack(device, drop=True):
    # Tap the village to deselect anything
    adb_tap(device, 158 + random.randint(-5, 5), 951 + random.randint(-5, 5))
    time.sleep(random.uniform(0.5, 1))
    adb_tap(device, 158 + random.randint(-5, 5), 951 + random.randint(-5, 5))
    time.sleep(0.3)

    # Use hardcoded attack button coordinate
    adb_tap(device, COORDS["backup_attack"][0], COORDS["backup_attack"][1])
    time.sleep(random.uniform(0.5, 1))

    # Wait for Find a Match button
    match_btn = wait_for_template(device, "templates/find_match.png", timeout=5)
    if match_btn:
        adb_tap(device, match_btn[0], match_btn[1])
    else:
        adb_tap(device, 386, 786)

    time.sleep(random.uniform(0.5, 1))

    # Confirm matchmaking screen
    adb_tap(device, 1900 + random.randint(-5, 5), 990 + random.randint(-5, 5))
    time.sleep(random.uniform(1, 2))

    # Wait for next button then drop troops
    drop_attack(device)

    # Wait for battle to end
    print(f"[{device}] Waiting for battle to end...")
    timeout = 200
    start_time = time.time()

    while time.time() - start_time < timeout:
        ret_home = wait_for_template(device, "templates/return_home.png", timeout=3)
        if ret_home:
            print(f"[{device}] Battle ended")
            for _ in range(2):
                adb_tap(device,
                        ret_home[0] + random.randint(-50, 50),
                        ret_home[1] + random.randint(-50, 50))
                time.sleep(random.uniform(0.2, 0.3))
            break
        time.sleep(1)


def drop_attack(device):
    attack_strat = random.randint(1, 3)
    left_x, left_y, right_x, right_y, mid_x, mid_y, rage_mid, rage_top, rage_bot, rage2_right_up, rage2_right_down = get_drop_coords(attack_strat)

    wait_for_template(device, "templates/next_button.png", timeout=15)

    adb_tap(device, 1500 + random.randint(-7, 7), 970 + random.randint(-7, 7))
    time.sleep(random.uniform(0.2, 0.5))

    adb_tap(device, random.randint(1000, 1700), random.randint(100, 400))
    time.sleep(random.uniform(0.3, 0.7))

    adb_tap(device, 140 + random.randint(-50, 50), 805 + random.randint(-20, 20))

    okay = wait_for_template(device, "templates/okay.png", timeout=5)
    if okay:
        for _ in range(random.randint(1, 2)):
            adb_tap(device,
                    okay[0] + random.randint(-50, 50),
                    okay[1] + random.randint(-20, 20))
            time.sleep(random.uniform(0.25, 0.4))

    attack(device)


def attack(device):
    adb_tap(device, 960, 540)
    time.sleep(0.4)
    adb_tap(device, 960, 540)
    time.sleep(0.4)

    attack_strat = random.randint(2, 3)
    _, _, _, _, mid_x, mid_y, *_ = get_drop_coords(attack_strat)

    def drop_point():
        return (mid_x + random.randint(-15, 15),
                mid_y + random.randint(-15, 15))

    # === Siege ===
    adb_tap(device, *jitter_coord(786, 992))
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.4)

    # === Electro Titans ===
    adb_tap(device, *jitter_coord(592, 975))
    time.sleep(0.2)
    for _ in range(4):
        adb_tap(device, *drop_point())
        time.sleep(random.uniform(0.12, 0.2))
    time.sleep(0.4)

    # === Yeti ===
    adb_tap(device, *jitter_coord(457, 977))
    time.sleep(0.25)
    for _ in range(10):
        adb_tap(device, *drop_point())
        time.sleep(random.uniform(0.12, 0.2))
    time.sleep(0.4)

    # === King ===
    adb_tap(device, *jitter_coord(941, 946))
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.4)

    # === Queen ===
    adb_tap(device, *jitter_coord(1084, 951))
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.4)

    # === Warden ===
    adb_tap(device, *jitter_coord(1230, 942))
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.4)

    # === Royal Champion ===
    adb_tap(device, *jitter_coord(1376, 949))
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.2)
    adb_tap(device, *drop_point())
    time.sleep(0.5)

    # === Ability re-triggers ===
    adb_tap(device, *jitter_coord(1230, 942))
    time.sleep(0.3)
    adb_tap(device, *jitter_coord(941, 946))
    time.sleep(0.5)

    # === Funnel / cleanup ===
    adb_tap(device, 1654 + random.randint(-7, 7), 965 + random.randint(-7, 7))
    time.sleep(0.3)

    if attack_strat == 2:
        points = [(988, 704), (791, 448), (1122, 535), (1026, 608), (1036, 360), (1351, 686)]
    else:
        points = [(1258, 270), (1380, 483), (1408, 685), (1300, 522), (1285, 644)]

    for x, y in points:
        adb_tap(device, x + random.randint(-7, 7), y + random.randint(-7, 7))
        time.sleep(random.uniform(0.25, 0.4))

    # === Rage timing ===
    time.sleep(random.uniform(15, 22))
    adb_tap(device, *jitter_coord(1513, 970))
    time.sleep(0.3)

    if attack_strat == 2:
        rage_points = [(1013, 307), (1035, 513), (1055, 689), (1409, 477), (1421, 679)]
        offset = 15
    else:
        rage_points = [(1258, 270), (1380, 483), (1408, 685), (900, 400), (980, 600)]
        offset = -40

    for x, y in rage_points:
        adb_tap(device,
                x + random.randint(-7, 7) + offset,
                y + random.randint(-7, 7))
        time.sleep(random.uniform(0.3, 0.6))
