import threading
import time
import random
from adb_utils import get_devices
from modes import farm_mode


def run_device(device, iterations):
    time.sleep(random.uniform(0.5, 2.0))
    farm_mode(device, iterations)


def main():
    devices = get_devices()

    if not devices:
        print("No devices found.")
        return

    print("Devices:", devices)

    try:
        iterations = int(input("How many attacks? "))
    except ValueError:
        iterations = 10

    threads = []
    for device in devices:
        t = threading.Thread(target=run_device, args=(device, iterations))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()


if __name__ == "__main__":
    main()
