COORDS = {
    "backup_attack": (218, 947),

    "rage_fallback1": (1432, 300),
    "rage_fallback2": (1120, 470),
    "rage_fallback3": (967, 650),
    "rage_fallback4": (1300, 500),
    "rage_fallback5": (1180, 710),
}

TROOP_COORDS = {
    "valk": (560, 1000),
    "apprentice": (670, 1000),
    "siege": (810, 1000),
    "queen": (940, 970),
    "warden": (1060, 970),
    "champion": (1170, 970),
    "king": (1290, 970),
    "spell": (1420, 1000),
}