from attack import find_attack


class GameActions:
    def __init__(self, device):
        self.device = device

    def deploy_attack(self):
        print(f"[{self.device}] Starting attack sequence")
        find_attack(self.device, drop=True)
