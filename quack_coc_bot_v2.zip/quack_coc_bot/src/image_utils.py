import cv2
import pytesseract
import re
import time
from adb_utils import capture_screen


def find_template(device, template_path, threshold=0.85):
    screen = capture_screen(device)
    template = cv2.imread(template_path)

    if screen is None:
        print(f"[{device}] ERROR: screen capture failed")
        return None

    if template is None:
        print(f"ERROR: template not found -> {template_path}")
        return None

    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(result)

    if max_val >= threshold:
        h, w = template.shape[:2]
        return (max_loc[0] + w // 2, max_loc[1] + h // 2)

    return None


def wait_for_template(device, template_path, timeout=3, threshold=0.85):
    start = time.time()

    while time.time() - start < timeout:
        coords = find_template(device, template_path, threshold)

        if coords:
            return coords

        time.sleep(0.2)  # prevents CPU spam

    return None


def read_trophies(device):
    screen = capture_screen(device)

    if screen is None:
        print(f"[{device}] ERROR: screen capture failed")
        return None

    import json, os
    CONFIG_PATH = os.path.join(os.path.dirname(__file__), "../config.json")

    with open(CONFIG_PATH, "r") as f:
        config = json.load(f)

    roi = config["trophy_roi"]
    x1, y1, x2, y2 = roi["x1"], roi["y1"], roi["x2"], roi["y2"]

    crop = screen[y1:y2, x1:x2]
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

    _, thresh = cv2.threshold(gray, 100, 255, cv2.THRESH_BINARY)

    text = pytesseract.image_to_string(
        thresh,
        config="--psm 7 -c tessedit_char_whitelist=0123456789"
    )

    match = re.findall(r"\d+", text)

    return int(match[0]) if match else None