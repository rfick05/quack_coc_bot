import time
import random
from game_actions import GameActions


def farm_mode(device, iterations):
    print(f"[{device}] Starting farm mode: {iterations} attacks")
    actions = GameActions(device)

    for i in range(iterations):
        print(f"[{device}] Attack {i + 1}/{iterations}")
        actions.deploy_attack()
        time.sleep(random.uniform(1.0, 3.0))

    print(f"[{device}] Farm mode complete")
